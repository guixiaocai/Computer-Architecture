#define	NIDE_CD	1
