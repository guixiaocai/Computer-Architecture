#define	NMOD_DEBUGGER	1
#define	NCMD_L	1
