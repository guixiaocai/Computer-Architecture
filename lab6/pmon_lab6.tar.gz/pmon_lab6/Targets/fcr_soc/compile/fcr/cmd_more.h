#define	NCMD_MORE	1
