#define	NCMD_ENV	1
#define	NCMD_SET	1
