#define	NMOD_S3LOAD	1
