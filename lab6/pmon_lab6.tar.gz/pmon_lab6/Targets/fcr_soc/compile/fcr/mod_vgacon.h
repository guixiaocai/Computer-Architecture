#define	NMOD_VGACON	1
